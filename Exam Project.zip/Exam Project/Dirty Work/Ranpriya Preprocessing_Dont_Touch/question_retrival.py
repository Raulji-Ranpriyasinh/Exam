import mysql.connector

# ✅ Configure Database Connection
db_config = {
    'host': 'localhost',
    'user': 'root',  # Change if different
    'password': '5525',  # Update with your MySQL password
    'database': 'Exam'  # Ensure this matches your database name
}

try:
    # ✅ Connect to MySQL
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor(dictionary=True)  # Enables fetching results as dictionaries

    # ✅ Fetch Questions
    cursor.execute("SELECT * FROM careerquestion")
    questions = cursor.fetchall()

    # ✅ Display Results
    if questions:
        for q in questions:
            print(f"ID: {q['question_number']}, Question: {q['question']}")
    else:
        print("No questions found.")

except mysql.connector.Error as e:
    print(f"Error: {e}")

finally:
    if 'cursor' in locals():
        cursor.close()
    if 'conn' in locals():
        conn.close()
