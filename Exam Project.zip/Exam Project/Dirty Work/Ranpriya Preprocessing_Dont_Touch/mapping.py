import mysql.connector
from docx import Document
import re

# Load the Word document containing mappings
doc = Document("question_mapping_arranged_ranpriya.docx")  # Ensure the correct filename

# Connect to MySQL
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="5525",
    database="EXAM"
)
cursor = conn.cursor()

# Check if the column "subject_code" exists in "careerquestion"
cursor.execute("""
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_NAME = 'careerquestion' 
    AND COLUMN_NAME = 'subject_code'
""")
column_exists = cursor.fetchone()[0]

# Add the column only if it does not exist
if column_exists == 0:
    cursor.execute("""
        ALTER TABLE careerquestion ADD COLUMN subject_code VARCHAR(255)
    """)
    print("✅ Column 'subject_code' added.")

# Parse the document for subject-question mappings
subject_mappings = {}
for para in doc.paragraphs:
    text = para.text.strip()
    if text:  # Skip empty lines
        match = re.match(r"(.+):\s*(.+)", text)
        if match:
            subject = match.group(1).strip()
            question_numbers = match.group(2).strip().split(", ")
            subject_mappings[subject] = [int(q) for q in question_numbers]

# Update the MySQL database with subject mappings
for subject, question_numbers in subject_mappings.items():
    for q_number in question_numbers:
        cursor.execute("""
            UPDATE careerquestion SET subject_code = %s WHERE question_number = %s
        """, (subject, q_number))
        print(f"Updated: Question {q_number} -> Subject {subject}")

# Commit and Close Connection
conn.commit()
cursor.close()
conn.close()
print("✅ Subject mappings updated successfully!")
































INSERT INTO careerquestion (question_number, category) VALUES
(11, 'Manufacturing & Production'),
(15, 'Manufacturing & Production'),
(41, 'Manufacturing & Production'),
(42, 'Manufacturing & Production'),
(43, 'Manufacturing & Production'),
(44, 'Manufacturing & Production'),
(46, 'Manufacturing & Production'),
(47, 'Manufacturing & Production'),
(53, 'Manufacturing & Production'),
(64, 'Manufacturing & Production'),
(149, 'Manufacturing & Production'),
(150, 'Manufacturing & Production'),
(152, 'Manufacturing & Production'),
(154, 'Manufacturing & Production'),
(156, 'Manufacturing & Production'),
(169, 'Manufacturing & Production'),
(170, 'Manufacturing & Production'),
(190, 'Manufacturing & Production'),
(199, 'Manufacturing & Production'),
(246, 'Manufacturing & Production'),
(8, 'Management:Organization & Planning'),
(22, 'Management:Organization & Planning'),
(28, 'Management:Organization & Planning'),
(31, 'Management:Organization & Planning'),
(49, 'Management:Organization & Planning'),
(57, 'Management:Organization & Planning'),
(62, 'Management:Organization & Planning'),
(67, 'Management:Organization & Planning'),
(83, 'Management:Organization & Planning'),
(84, 'Management:Organization & Planning'),
(94, 'Management:Organization & Planning'),
(108, 'Management:Organization & Planning'),
(118, 'Management:Organization & Planning'),
(122, 'Management:Organization & Planning'),
(136, 'Management:Organization & Planning'),
(137, 'Management:Organization & Planning'),
(150, 'Management:Organization & Planning'),
(153, 'Management:Organization & Planning'),
(164, 'Management:Organization & Planning'),
(169, 'Management:Organization & Planning'),
(218, 'Management:Organization & Planning'),
(222, 'Management:Organization & Planning'),
(241, 'Management:Organization & Planning'),
(264, 'Management:Organization & Planning'),
(271, 'Management:Organization & Planning'),
(64, 'Electronics/Electrical Engineering'),
(117, 'Electronics/Electrical Engineering'),
(158, 'Electronics/Electrical Engineering'),
(171, 'Electronics/Electrical Engineering'),
(219, 'Electronics/Electrical Engineering'),
(233, 'Electronics/Electrical Engineering'),
(243, 'Electronics/Electrical Engineering'),
(246, 'Electronics/Electrical Engineering'),
(258, 'Electronics/Electrical Engineering'),
(263, 'Electronics/Electrical Engineering'),
(120, 'Computing/IT'),
(145, 'Computing/IT'),
(157, 'Computing/IT'),
(158, 'Computing/IT'),
(192, 'Computing/IT'),
(213, 'Computing/IT'),
(245, 'Computing/IT'),
(247, 'Computing/IT'),
(258, 'Computing/IT'),
(266, 'Computing/IT'),
(41, 'Mechanical & Related Engineering'),
(43, 'Mechanical & Related Engineering'),
(44, 'Mechanical & Related Engineering'),
(47, 'Mechanical & Related Engineering'),
(52, 'Mechanical & Related Engineering'),
(53, 'Mechanical & Related Engineering'),
(64, 'Mechanical & Related Engineering'),
(117, 'Mechanical & Related Engineering'),
(158, 'Mechanical & Related Engineering'),
(171, 'Mechanical & Related Engineering'),
(190, 'Mechanical & Related Engineering'),
(199, 'Mechanical & Related Engineering'),
(233, 'Mechanical & Related Engineering'),
(263, 'Mechanical & Related Engineering'),
(246, 'Mechanical & Related Engineering'),
(14, 'Physics'),
(15, 'Physics'),
(16, 'Physics'),
(17, 'Physics'),
(57, 'Physics'),
(59, 'Physics'),
(68, 'Physics'),
(70, 'Physics'),
(159, 'Physics'),
(256, 'Physics'),
(42, 'Creative Arts and Crafts'),
(48, 'Creative Arts and Crafts'),
(49, 'Creative Arts and Crafts'),
(50, 'Creative Arts and Crafts'),
(52, 'Creative Arts and Crafts'),
(80, 'Creative Arts and Crafts'),
(81, 'Creative Arts and Crafts'),
(82, 'Creative Arts and Crafts'),
(84, 'Creative Arts and Crafts'),
(85, 'Creative Arts and Crafts'),
(86, 'Creative Arts and Crafts'),
(87, 'Creative Arts and Crafts'),
(89, 'Creative Arts and Crafts'),
(204, 'Creative Arts and Crafts'),
(238, 'Creative Arts and Crafts'),
(244, 'Creative Arts and Crafts'),
(261, 'Creative Arts and Crafts'),
(271, 'Creative Arts and Crafts'),
(277, 'Creative Arts and Crafts');
