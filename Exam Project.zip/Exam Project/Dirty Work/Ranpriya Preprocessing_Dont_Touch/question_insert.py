import mysql.connector
from docx import Document

# Load Word document
doc = Document("Question.docx")  # Ensure correct path

# Connect to MySQL
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="5525",
    database="EXAM"
)
conn.autocommit = True  # Ensure data is saved automatically
cursor = conn.cursor()

# Create Table (if not exists)
cursor.execute("""
CREATE TABLE IF NOT EXISTS careerquestion (
    question_number INT AUTO_INCREMENT PRIMARY KEY,  -- Auto-increment question number
    question TEXT
)
""")

# Extract Questions and Insert into MySQL
for para in doc.paragraphs:
    question_text = para.text.strip()
    
    if question_text:  # Skip empty lines
        print(f"Inserting: {question_text}")  # Debugging
        
        cursor.execute(
            "INSERT INTO careerquestion (question) VALUES (%s)", 
            (question_text,)
        )

# Commit and Close Connection
conn.commit()
cursor.close()
conn.close()
print("✅ Questions Inserted Successfully!")
