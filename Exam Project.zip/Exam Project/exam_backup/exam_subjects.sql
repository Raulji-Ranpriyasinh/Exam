-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: exam
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `subjects`
--

DROP TABLE IF EXISTS `subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subjects` (
  `subject_id` int NOT NULL AUTO_INCREMENT,
  `subject_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`subject_id`),
  UNIQUE KEY `subject_name` (`subject_name`)
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subjects`
--

LOCK TABLES `subjects` WRITE;
/*!40000 ALTER TABLE `subjects` DISABLE KEYS */;
INSERT INTO `subjects` VALUES (17,'Academic Art'),(34,'Administrative'),(23,'Advertising/Marketing/PR'),(47,'Agricultural Sciences'),(49,'Agriculture and Land-Based'),(38,'Biology Based'),(22,'Charity/Fundraising/Voluntary Work'),(30,'Chemical Technologies'),(44,'Chemistry Based'),(42,'Commercial and Financial Dealing/Advice'),(16,'Commercial Art/Antiques'),(31,'Complementary Therapies'),(4,'Computing/IT'),(39,'Construction and Property-Related'),(7,'Creative Arts and Crafts'),(3,'Electronics/Electrical Engineering'),(45,'English/Literary Related'),(27,'Environmental'),(14,'Fashion/Clothing/Textile'),(36,'Financial'),(51,'Geography and Geology Related'),(15,'Graphic Design'),(29,'History Related'),(40,'Hospitality and Events Management'),(28,'Information Management'),(24,'Landscape Design/Surveying'),(50,'Language-Related'),(41,'Law-Related'),(2,'Management: Organization & Planning'),(1,'Manufacturing & Production'),(20,'Mathematics Based Careers'),(5,'Mechanical & Related Engineering'),(46,'Media and Journalism'),(48,'Medicine/Dentistry/Veterinary'),(18,'Musical Performing Art'),(11,'Nursing and Allied Health Protection'),(8,'Performing Arts Related'),(6,'Physics'),(25,'Politics and Government'),(12,'Psychology'),(9,'Public Protection & Security'),(26,'Publishing'),(43,'Retail Buying and Selling'),(21,'Social care, religion, guidance and recruitment'),(10,'Sports/Leisure/Recreation'),(35,'Structural Design'),(33,'Structural Engineering'),(37,'Surveying'),(19,'Teaching/Advisory'),(13,'Theatrical Support'),(32,'Transport/Travel/Logistics/Distribution');
/*!40000 ALTER TABLE `subjects` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-15 10:07:33
